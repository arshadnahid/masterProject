<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/*Manue type*/
$lang['Operation'] = 'operation';
$lang['Setup'] = 'setup';
$lang['Reort'] = 'reort';
/*Manue type*/
/*Sales  Manue start*/
$lang['Sales'] = 'sales';

$lang['Sales_Invoice'] = 'Sales invoice';
$lang['Customer_Payment'] = 'Customer Payment';
$lang['Pending_Cheque'] = 'Pending Cheque';



$lang['Customer_List'] = 'Customer List';
$lang['Reference'] = 'Reference';

$lang['Date_Range_Wise_Product_Sales'] = 'Date Range Wise Product Sales';
$lang['Date_Wise_Product_Sales']='Date Wise Product Sales';
$lang['Customer_Due']='Customer Due';
$lang['Sales_Report']='Sales Report';
$lang['Customer_Sales_Report']='Customer Sales Report';
$lang['Product_Wise_Sales ']='Product Wise Sales';
$lang['Reference_Sales_Report']='Reference Sales_Report';
$lang['Brand_Wise_Profit']='Brand Wise Profit';
$lang['Cylinder_Sales_Report']='Cylinder Sales Report';
$lang['Sales_Report_Brand_wise']='Sales Report Brand_wise';
$lang['Daily_Sales_Statement']='Daily Sales Statement';
/*Sales  Manue end*/
/*Inventory  Manue start*/

$lang['Inventory']='Inventory';

$lang['Purchases_Voucher']='Purchases Voucher';
$lang['Supplier_Payment']='Supplier Payment';
$lang['Pending_Cheque']='Pending Cheque';


$lang['Supplier_List']='Supplier List';
$lang['Product_Category']='Product Category';
$lang['Product_Add']='Product Add';
$lang['Brand']='Brand';
$lang['Unit']='Unit';
$lang['Product_Barcode']='Product Barcode';
$lang['Product_Type']='Product Type';
$lang['Product_Package']='Product Package';
$lang['Cylinder_Report']='Cylinder Report';
$lang['Current_Stock']='Current Stock';
$lang['Current_Stock_Value']='Current_Stock_Value';
$lang['Stock_Report']='Stock_Report';
$lang['Supplier_Wise_Purchas']='Supplier Wise Purchas';
$lang['Product_Wise_Purchases']='Product Wise Purchases';
$lang['Purchases_Report']='Purchases Report';
$lang['Low_Inventory_Report']='Low Inventory Reportrt';
$lang['Product_Ledger']='Product Ledger';

$lang['Inventory_Report']='Inventory report';
$lang['New_Cylinder_Stock_Report']='New Cylinder Stock Report';
$lang['Customer_Wise_Cylinder']='Customer Wise Cylinder';
$lang['Product_Wise_Cylinder']='Product Wise Cylinder';
$lang['Cylinder_Exchange']='Cylinder Exchange';
$lang['Cylinder_Ledger']='Cylinder Ledger';
$lang['Cylinder_combine_Report']='Cylinder combine Report';
$lang['Cylinder_Type_Report']='';
$lang['Cylinder_Summary_Report']='Cylinder Summary Report';
$lang['Cylinder_Details_Repor']='Cylinder Details Repor';
$lang['Cylinder_Stock_Report']='Cylinder Stock Report';
$lang['Stock_Group_Report']='Stock Group Report';

/*Inventory  Manue End*/
/*Accounts  Manue Start*/

$lang['Accounts']='Accounts';

$lang['Payment_Voucher']='Payment Voucher';
$lang['Receive_Voucher']='Receive Voucher';
$lang['Journal_Voucher']='Journal Voucher';
$lang['Bill_Voucher']='Bill Voucher';

//setup
$lang['List_Chart_of_Account']='List Chart of Account';
$lang['View_Chart_of_Account']='View Chart of Account';

//report
$lang['General_Ledger']='General_Ledger';
$lang['Trial_Balance']='Trial Balance';
$lang['Balance_Sheet']='Balance Sheet';
$lang['Income_Statement']='Income Statement';
$lang['Cash_Flow']='Cash Flow';
$lang['Cash_Book']='Cash Book';
$lang['Bank_Book']='Bank Book';
$lang['Customer_Ledger']='Customer Ledger';
$lang['Supplier_Ledger']='Supplier Ledger';
/*Accounts  Manue End*/


$lang['Configuration']='configuration';
//Operation
$lang['Opening_Balance']='Opening Balance';
$lang['Opening_Inventory']='Opening Inventory';
$lang['Supplier_Opening']='Supplier Opening';
$lang['Customer_Opening']='Customer Opening';
$lang['Cylinder_Opening']='Cylinder Opening';


$lang['System_Config']='System Config';
$lang['User_Access']='User Access';
$lang['User_List']=' User List';
$lang['Login_History']='Login History';
$lang['Incentive']='Incentive';
$lang['Vehicle']='Vehicle';

$lang['Import']='import';


/*Dashboard body*/
$lang['Admin_Dashbord']='Admin_Dashbord';
$lang['Product_sales']='Product_sales';
$lang['Date_Wise_Sales']='Date_Wise_Sales';
$lang['Date_Wise_Purchase']='Date_Wise_Purchase';
$lang['Month_Wise_Purchase']='Month_Wise_Purchase';
$lang['By_Advanced_Equipment_Limited']='By_Advanced_Equipment_Limited';
$lang['Month_Wise_Sales Month_Wise_Sales']='Month_Wise_Sales';
$lang['Purchase']='Purchase ';
$lang['Cash_At_Bank']='Cash_At_Bank';
$lang['Cash_In_Hand']='Cash_In_Hand';
$lang['Account_Payable']='Account_Payable';
$lang['Account_Receivable']=' Account_Receivable ';




/*sales invoice add form*/
$lang['New_Sale_Invoice'] = 'New Sale Invoice';
$lang['Invoice_List'] = 'Invoice List';
$lang['Sales_Date'] = 'Sales_Date';
$lang['Invoice_No'] = 'Invoice No';

$lang['Loader'] = 'Loader';
$lang['Transportation'] = 'Transportation';
$lang['Trans'] = 'Transportation';
$lang['Delivery_Address'] = 'Delivery_Address';
$lang['Delivery_Date'] = 'Delivery Date';
$lang['Bank_Name'] = 'Delivery Date';
$lang['Branch_Name'] = 'Branch Name';
$lang['Check_No'] = 'Check No';
$lang['Check_Date'] = 'Check Date';
$lang['Payment_Type'] = 'Payment Type';
$lang['Account'] = 'Account';
$lang['Address'] = 'address';
$lang['Phone']='Phone';
$lang['Due']='Due';
$lang['Si']='Si';
$lang['Product']='Product';
$lang['Qty']='Qty';
$lang['Category']='Category';
$lang['Quantity']='Quantity';
$lang['Receivable_Qty']='Receivable (Qty)';
$lang['BDT']='BDT';
$lang['Unit_Price']='Unit Price';
$lang['Total_Price']='Total_Price';
$lang['Returned_Cylinder']='Returned Cylinder';
$lang['Returned_Qty']='Returned Qty';
$lang['Action']='Action';
$lang['Save']='Save';
$lang['Total']='Total';
$lang['Discount']='Discount';
$lang['Grand_Total']='Grand_Total';
$lang['Vat']='Vat';
$lang['Net_Total']='Net_Total';
$lang['Payment']='Payment';
$lang['Due_Amount']='Due_Amount';
$lang['Invoice_List']='Invoice_List';
$lang['Cash']='Cash';
$lang['Credit']='Credit';
$lang['Cheque_DD_PO']='Cheque/DD/PO';
$lang['Payment_Calculation']='Payment Calculation';

/*sales invoice list*/
$lang['Date']='Date';
$lang['Sv_No']='Sv_No';
$lang['Customer']='Customer';
$lang['Narration']='Narration';
$lang['Amount']='Amount';


/*sales invoice list*/


/*sales invoice Edit*/
$lang['Sale_Invoice_Edit']='Sale_Invoice_Edit';
/*sales invoice Edit*/

/*sales invoice view*/
$lang['Sale_Invoice_View']='Sale_Invoice_View';
$lang['Invoice_ID']='Invoice_ID';
$lang['Invoice_Info']='Invoice_Info';
$lang['Company_Info']='Company_Info';
$lang['Name']='Name';
$lang['Email']='Email';
$lang['Phone']='Phone';
$lang['Address']='Address';
$lang['Current_Due']='Current_Due';
$lang['Recive_Product']='Recive_Product';
$lang['Quantity_Recived']='Quantity_Recived';
$lang['Sub_Total']='Sub - Total';
$lang['In_Words']='In_Words';
$lang['Prepared_By']='Prepared_By';
$lang['Approved_By']='Approved_By';
/*sales invoice view*/

/*customerPayment*/
$lang['Customer_Payment_List']='Customer_Payment_List';
/*customerPayment*/
/*customerPaymentAdd*/
$lang['Receipt_Id']='Receipt_Id';
$lang['Deposit_Dr']='Deposit(DR)';
/*customerPayment*/

/*viewMoneryReceipt*/
$lang['Customer_Money_Receipt']='Customer_Money_Receipt';
$lang['Received_With_Thanks_From']='Received_With_Thanks_From';
$lang['Amount_In_Tk']='Amount_In_Tk';
$lang['The_Sum_Of_Taka_In_Words']='The_Sum_Of_Taka_In_Words';
$lang['On_Account_Of']='On_Account_Of';
$lang['By_Cash']='By_Cash';
/*viewMoneryReceipt*/

/*pendingCheck*/
$lang['Customer_Pending_Cheque']='Customer_Pending_Cheque';
$lang['Voucher_No']='Voucher_No';
$lang['Cheque_Date']='Cheque_Date';
$lang['Amount_In_Ddt']='Amount_In_Ddt';
$lang['Receive']='Receive';
$lang['Dishonour']='Dishonour';
/*pendingCheck*/


/*customerList*/
$lang['Customer_Type']='Customer_Type';
$lang['Customer_Id']='Customer_Id';
$lang['Status']='Status';
$lang['Showing']='Showing';
$lang['Entries']='Entries';
/*customerList*/


/*reference*/
$lang['Reference_List']='Reference_List';
/*reference*/


/*editReference*/
$lang['Reference_Edit']='Reference_Edit';
$lang['Referencen_Name']='Referencen_Name';
$lang['Update']='Update';
$lang['Reset']='Reset';
/*editReference*/

/*date_wise_product_sales*/
$lang['Date_Wise_Product_Sales_Statement']='Date_Wise_Product_Sales_Statement';

$lang['Product_Name']='Product_Name';
$lang['Sales_Qty']='Sales_Qty';
$lang['Sales_Price']='Sales_Price';
$lang['Total_Sales']='Total_Sales';
/*date_wise_product_sales*/


/*date_wise_product_sales_by_date*/
$lang['Search']='Search';
$lang['Print']='Print';
/*date_wise_product_sales_by_date*/


/*customer_due*/
$lang['From']='From';
$lang['To']='To';
$lang['Customer_Due_Rec']='Customer_Due_Rec.';
$lang['Net_Amount']='Net_Amount';
/*customer_due*/


/*salesReport*/
$lang['From_Date']='From_Date';
$lang['To_Date']='To_Date';
$lang['Memo']='Memo';
$lang['Total_Sales_Amount']='Total_Sales_Amount';
/*salesReport*/


/*customerSalesReport*/
$lang['First_Name']='First_Name';
$lang['Last_Name']='Last_Name';
$lang['Position']='Position';
$lang['Salary']='Salary';
/*customerSalesReport*/


/*productWiseSalesReport*/
$lang['Website']='Website';
$lang['Stock_Report']='Stock_Report';
$lang['Total_Sales_Price_Bdt']='Total_Sales_Price_(Bdt)';
$lang['Gp_Profit']='Gp_Profit';
/*productWiseSalesReport*/


/*referenceSalesReport*/
$lang['Reference_Sales_Report_List']='';
$lang['Reference_Sales_Report_Period']='';
$lang['Opening_Balance']='';
$lang['Total_Sales_Amount']='';
/*referenceSalesReport*/

/*brandWiseProfit*/
$lang['Product_Ledger']='Product_Ledger';
$lang['Product_Ledger_Report']='Product_Ledger_Report';
$lang['Voucher']='Voucher';
$lang['Stock_In']='Stock_In';
$lang['Stock_Out']='Stock_Out';
$lang['Balance']='Balance';
/*brandWiseProfit*/

/*cylinder_sales_report*/
$lang['Customer_Wise_Sales_Report']='Customer_Wise_Sales_Report';
$lang['Sold_Product']='Sold_Product';
$lang['Quantity_Received']='Quantity_Received';
$lang['Quantity_Sold']='Quantity_Sold';
$lang['Rate']='Rate';
/*cylinder_sales_report*/


/*Cylinder_Sales_Report*/
$lang['Cylinder_Sales_Report']='Cylinder_Sales_Report';
/*Cylinder_Sales_Report*/



/*sales_report_brand_wise*/
/*sales_report_brand_wise*/
/*daily_sales_statement*/
/*daily_sales_statement*/

/*purchases_add*/
$lang['Purchases_Date']='Purchases_Date';
$lang['Supplier_Id']='Supplier_Id';
$lang['Due_Date']='Due_Date';
$lang['Payment_Type']='Payment_Type';
$lang['Voucher_Id']='Voucher_Id';
$lang['Purchases_Item']='Purchases_Item';
$lang['Returnable_Qty']='Returnable_Qty';
$lang['Unit_Price_Bdt']='Unit_Price_Bdt';
$lang['Total_Price_Bdt']='Total_Price_Bdt';
$lang['Returned_Cylinder']='Returned_Cylinder';
$lang['Previous_Due']='Previous_Due';
$lang['Total_Due']='Total_Due';
/*purchases_add*/


/*purchases_list*/
$lang['Purchases_List']='Purchases_List';
$lang['Pv_No']='Pv_No';
$lang['Supplier']='Supplier';
$lang['Records']='Records';
/*purchases_list*/


/*viewPurchases*/
$lang['Purchases_View']='Purchases_View';
$lang['Return_Product']='Return_Product';
$lang['Quantity_Return']='Quantity_Return';
$lang['Quantity']='Quantity';
$lang['Unit_Price']='Unit_Price';
$lang['Total_Price']='Total_Price';
/*viewPurchases*/

/*supplierPayment*/
$lang['Supplier_Payment_Add']='Supplier_Payment_Add';
$lang['Supplier_Payment']='Supplier_Payment';
$lang['Payment_Date']='Payment_Date';
$lang['Supplier_Payment_List']='Supplier_Payment_List';
$lang['Search_By_Account_Head']='Search_By_Account_Head';
/*supplierPayment*/


/*supPendingCheque*/
$lang['Supplier_Pending_Cheque']='Supplier_Pending_Cheque';
$lang['Supplier_Name']='Supplier_Name';
$lang['Bank_Branch']='Bank_Branch';
$lang['Cheque_No']='Cheque_No';
$lang['Cheque_Date']='Cheque_Date';
$lang['Amount_In_Bdt']='Amount_In_Bdt';
/*supPendingCheque*/


/*Supplier_List*/
$lang['Supplier_Add']='Supplier_Add';
/*Supplier_List*/

/*productCatList*/
$lang['Product_Category']='Product_Category';
$lang['Product_Cat_Name']='Product_Cat_Name';
$lang['Product_Category_Add']='Product_Category_Add';
/*productCatList*/


/*addProduct*/
$lang['Add_Product']='Add_Product';
$lang['Product_Code']='Product_Code';
$lang['Model_Name']='Model_Name';
$lang['Purchases_Price']='Purchases_Price';
$lang['Retail_Price_Mrp']='Retail_Price_Mrp';
$lang['Wholesale_Price']='Wholesale_Price';
$lang['Alarm_Quantity']='Alarm_Quantity';
/*addProduct*/



/*brand*/
$lang['Brand_List']='Brand_List';
$lang['Brand_Add']='Brand_Add';
$lang['Brand_Title']='Brand_Title';
/*brand*/

/*band_add */
$lang['Band_Name ']='Band_Name';
/*band_add */


/*unit */
$lang['Unit_List']='Unit_List';
$lang['Unit_Name']='Unit_Name';
$lang['Unit_Code']='Unit_Code';
/*unit */


/*unitAdd */
$lang['Unit_Add']='Unit_Add';
/*unitAdd */

/*productBarcode */
$lang['Product_Barcode']='Product_Barcode';
$lang['Product_Barcode_List']='Product_Barcode_List';
$lang['All_Check']='All_Check';
$lang['All_Product']='All_Product';
$lang['Generate_Barcode']='Generate_Barcode';
/*productBarcode */

/*productType */
$lang['Product_Type_List']='পণ্যের ধরণের তালিকা';
$lang['Product_Type_Add']='পণ্যের ধরণ যোগ করা';
/*productType */


/*addproductTyp */
$lang['Product_Type_Name']='Product_Type_Name';
$lang['Description']='Description';
/*addproductTyp */

