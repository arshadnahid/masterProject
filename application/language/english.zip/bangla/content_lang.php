<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/*Manue type*/
$lang['Operation'] = 'অপারেশন';
$lang['Setup'] = 'বিন্যাস';
$lang['Report'] = 'রিপোর্ট';
/*Manue type*/
/*Sales  Manue start*/
$lang['Sales'] = 'বিক্রয়';

$lang['Sales_Invoice'] = 'বিক্রয় চালান';
$lang['Customer_Payment'] = 'কাস্টমার প্রেমেন্ট';
$lang['Pending_Cheque'] = 'প্রেন্ডিং চেক';


$lang['Customer_List'] = 'গ্রাহকের তালিকা';
$lang['Reference'] = 'রেফারেঞ্চ';

$lang['Date_Range_Wise_Product_Sales'] = 'তারিখের সীমা অনুসারে পণ্য বিক্রয়';
$lang['Date_Wise_Product_Sales']='তারিখ অনুসারে পণ্য বিক্রয়';
$lang['Customer_Due']='গ্রাহকের বকেয়া';
$lang['Sales_Report']='বিক্রয় রিপোর্ট';
$lang['Customer_Sales_Report']='গ্রাহক বিক্রয় রিপোর্ট';
$lang['Product_Wise_Sales']='পণ্য অনুসারে বিক্রয়';
$lang['Reference_Sales_Report']='রেফারেন্স বিক্রয় প্রতিবেদন';
$lang['Brand_Wise_Profit']='ব্র্যান্ড অনুসারে লাভ';
$lang['Cylinder_Sales_Report']='সিলিন্ডার বিক্রয় রিপোর্ট';
$lang['Sales_Report_Brand_wise']='বিক্রয় রিপোর্ট ব্র্যান্ড অনুযায়ী';
$lang['Daily_Sales_Statement']='দৈনিক বিক্রয় বিবৃতি';

/*Sales  Manue end*/
/*Inventory  Manue start*/

$lang['Inventory']='ইনভেন্টরি';


$lang['Purchases_Voucher']='কেনাকাটা রশিদ ';
$lang['Supplier_Payment']='সরবরাহকারী প্রদান';
$lang['Pending_Cheque']='প্রেন্ডিং চেক';


$lang['Supplier_List']='সরবরাহকারী তালিকা';
$lang['Product_Category']='পণ্য তালিকা';
$lang['Product_Add']='পণ্য যোগ করুণ ';
$lang['Brand']='ব্রান্ড';
$lang['Unit']='একক';
$lang['Product_Barcode']='পণ্য বারকোড';
$lang['Product_Type']='পণ্যের ধরন';
$lang['Product_Package']='পণ্য প্যাকেজ';
$lang['Cylinder_Report']='সিলিন্ডার রিপোর্ট';
$lang['Current_Stock']='বর্তমান স্টক';
$lang['Current_Stock_Value']='বর্তমান স্টক পরিমাণ';
$lang['Stock_Report']='তহবিল রিপোর্ট';
$lang['Supplier_Wise_Purchas']='সরবরাহকারী অনুসারে ক্রয়';
$lang['Product_Wise_Purchases']='পণ্য অনুসারে ক্রয়';
$lang['Purchases_Report']='ক্রয় প্রতিবেদন';
$lang['Low_Inventory_Report']='কম তালিকা রিপোর্ট';
$lang['Product_Ledger']='পণ্যের খতিয়ান';

$lang['Inventory_Report']='পরিসংখ্যা প্রতিবেদন';
$lang['New_Cylinder_Stock_Report']='নতুন সিলিন্ডার স্টক রিপোর্ট';
$lang['Customer_Wise_Cylinder']='ক্রেতা অনুযায়ী সিলিন্ডার';
$lang['Product_Wise_Cylinder']='পণ্যে অনুযায়ী সিলিন্ডার';
$lang['Cylinder_Exchange']='সিলিন্ডার বিনিময়';
$lang['Cylinder_Ledger']='সিলিন্ডার খতিয়ান';
$lang['Cylinder_combine_Report']='একরিত সিলিন্ডার প্রতিবেদন';
$lang['Cylinder_Type_Report']='সিলিন্ডারের টাইপ প্রতিবেদন';
$lang['Cylinder_Summary_Report']='সিলিন্ডারের সারাংশ রিপোর্ট';
$lang['Cylinder_Details_Repor']='সিলিন্ডারের বিস্তারিত রিপোর্ট';
$lang['Cylinder_Stock_Report']='সিলিন্ডার স্টক রিপোর্ট';
$lang['Stock_Group_Report']='স্টক গ্রুপ রিপোর্ট';

/*Inventory  Manue End*/

/*Accounts  Manue Start*/

$lang['Accounts']='গাণিতিক';

$lang['Payment_Voucher']='পেমেন্ট রশিদ';
$lang['Receive_Voucher']='গ্রহণ রশিদ ';
$lang['Journal_Voucher']='দৈনিক হিসাবের রশিদ';
$lang['Bill_Voucher']='বিল ভাউচার';

//setup
$lang['List_Chart_of_Account']='অ্যাকাউন্টের তালিকা';
$lang['View_Chart_of_Account']='অ্যাকাউন্টের চার্ট দেখুন';

//report
$lang['General_Ledger']='জেনারেল লেজার';
$lang['Trial_Balance']='ট্রায়াল ব্যালেন্স';
$lang['Balance_Sheet']='ব্যালেন্স শীট';
$lang['Income_Statement']='আয় বিবৃতি';
$lang['Cash_Flow']='নগদ প্রবাহ';
$lang['Cash_Book']='নগদ বই';
$lang['Bank_Book']='ব্যাংক বই';
$lang['Customer_Ledger']='গ্রাহক খতিয়ান';
$lang['Supplier_Ledger']='সরবরাহকারী খতিয়ান';
/*Accounts  Manue End*/


$lang['Configuration']='কনফিগারেশন';
//Operation
$lang['Opening_Balance']='উদ্বোধন ব্যালেন্স';
$lang['Opening_Inventory']='উদ্বোধন ইনভেন্টরি/';
$lang['Supplier_Opening']='সরবরাহকারী উদ্বোধন ';
$lang['Customer_Opening']='গ্রাহক উদ্বোধন ';
$lang['Cylinder_Opening']='সিলিন্ডার উদ্বোধন';

$lang['System_Config']='সিস্টেম কনফিগ';
$lang['User_Access']='ইউজার অ্যাক্সেস ';
$lang['User_List']=' ব্যবহারকারীর তালিকা ';
$lang['Login_History']='ব্যবহারকারীর তালিকা ';
$lang['Incentive']='উদ্দীপক';
$lang['Vehicle']='বাহন';

$lang['Import']='আমদানি';
/*Dashboard body*/

$lang['Admin_Dashbord']='Admin Dashbord';
$lang['Product_sales']='Product sales';
$lang['Date_Wise_Sales']='তারিখ অনুযায়ী বিক্রয়';
$lang['Date_Wise_Purchase']='তারিখ অনুযায়ী ক্রয়';
$lang['Month_Wise_Purchase']='মাস অনুযায়ী ক্রয়';
$lang['By_Advanced_Equipment_Limited']='বাই অ্যাডভান্স ইকুইপমেন্ট লিমিটেড ';
$lang['Month_Wise_Sales']='মাস অনুযায়ী বিক্রয়';
$lang['Purchase']='কেনাকাটা ';
$lang['Cash_At_Bank']='ব্যাংকে নগদ';
$lang['Cash_In_Hand']='নগদ তহবিল';
$lang['Account_Payable']='Account_Payable';
$lang['Account_Receivable']=' Account_Receivable ';
/*Dashboard body*/

/*sales invoice add form*/
$lang['New_Sale_Invoice'] = 'নতুন বিক্রয় চালান ';
$lang['Invoice_List'] = 'চালান তালিকা';
$lang['Sales_Date'] = 'বিক্রয় তারিখ';
$lang['Invoice_No'] = 'চালান নং';

$lang['Loader'] = 'লোডার';
$lang['Transportation'] = 'পরিবহন';
$lang['Trans'] = 'পরিবহন';
$lang['Delivery_Address'] = 'সরবরাহের ঠিকানা';
$lang['Delivery_Date'] = 'সরবরাহের তারিখ';
$lang['Bank_Name'] = 'ব্যাংকের নাম';
$lang['Branch_Name'] = 'শাখার নাম Name';
$lang['Check_No'] = 'চেক নং ';
$lang['Check_Date'] = 'চেক তারিখ ';
$lang['Payment_Type'] = 'পেমেন্ট টাইপ ';
$lang['Account'] = 'হিসাব';
$lang['Address'] = 'ঠিকানা';

$lang['Phone']='ফোন';
$lang['Due']='বাকী ';
$lang['Si']='ক্রমিক';
$lang['Product']='পণ্য';
$lang['Qty']='পরিমাণ';
$lang['Category']='বিভাগ';
$lang['Quantity']='পরিমাণ';
$lang['Receivable_Qty']='প্রাপ্য অংশের পরিমাণ';
$lang['BDT']='BDT';
$lang['Unit_Price']='একক দাম ';
$lang['Total_Price']='মোট মূল্য';
$lang['Returned_Cylinder']='ফেরত সিলিন্ডার ';
$lang['Returned_Qty']='ফেরতের পরিমাণ';
$lang['Action']='কার্যকলাপ';
$lang['Save']='সেভ';
$lang['Total']='মোট মূল্য';
$lang['Discount']='ডিসকাউন্ট';
$lang['Grand_Total']='সর্বমোট';
$lang['Vat']='ভ্যাট ';
$lang['Net_Total']='সর্বমোট';
$lang['Payment']='পেমেন্ট ';
$lang['Due_Amount']='বাকি টাকা';
$lang['Invoice_List']='চালান তালিকা ';
$lang['Cash']='Cash';
$lang['Credit']='Credit';
$lang['Cheque_DD_PO']='Cheque/DD/PO';
$lang['Payment_Calculation']='Payment Calculation';

/*sales invoice list*/
$lang['Date']='তারিখ';
$lang['Sv_No']='এস ভি নং ';
$lang['Customer']='ক্রেতা';
$lang['Narration']='বর্ণনা';
$lang['Amount']='পরিমাণ';


/*sales invoice list*/

/*sales invoice Edit*/

$lang['Sale_Invoice_Edit']='Sale Invoice Edit';
/*sales invoice Edit*/



/*sales invoice View*/
$lang['Sale_Invoice_View']='বিক্রয় চালানের ভিউ';
$lang['Invoice_ID']='চালানের আইডি';

$lang['Invoice_Info']='চালানের তথ্য ';
$lang['Company_Info']='প্রতিষ্ঠানের তথ্য';
$lang['Name']='নাম ';
$lang['Email']='ইমেইল ';
$lang['Phone']='ফোন ';
$lang['Address']='ঠিকানা';
$lang['Current_Due']='বর্তমান বাকী ';
$lang['Recive_Product']='পণ্য গ্রহণ';
$lang['Quantity_Recived']='পরিমাণ প্রাপ্ত';
$lang['Sub_Total']='উপ - মোট';
$lang['In_Words']='শব্দসমূহ ';
$lang['Prepared_By']='প্রস্তুতকারক';
$lang['Approved_By']='অনুমোদিত';
/*sales invoice view*/



/*sales invoice Edit*/

/*customerPayment*/
$lang['Customer_Payment_List']='গ্রাহক পেমেন্টের তালিকা';
/*customerPayment*/
/*customerPaymentAdd*/
$lang['customerPaymentAdd']='customerPaymentAdd';
/*customerPayment*/

/*customerPaymentAdd*/
$lang['Receipt_Id']='Receipt_Id';
$lang['Deposit_Dr']='Deposit(DR)';
/*customerPayment*/

/*viewMoneryReceipt*/
$lang['Customer_Money_Receipt']='গ্রাহক মানি রসিদ';
$lang['Received_With_Thanks_From']='ধন্যবাদ সাথে গৃহীত হয়েছে';
$lang['Amount_In_Tk']='পরিমাণ টাকায় ';
$lang['The_Sum_Of_Taka_In_Words']='কথায় টাকার যোগফল';
$lang['On_Account_Of']='হিসাব ';
$lang['By_Cash']='নগদে';
/*viewMoneryReceipt*/


/*pendingCheck*/
$lang['Customer_Pending_Cheque']='গ্রাহক পেন্ডিং চেক';
$lang['Voucher_No']='ভাউচার নং';
$lang['Cheque_Date']='চেকের তারিখ ';
$lang['Amount_In_Ddt']='পরিমাণ (বিডিটিতে)';
$lang['Receive']='গ্রহণ করা';
$lang['Dishonour']='অসম্মান';
/*pendingCheck*/


/*customerList*/
$lang['Customer_Type']='কাস্টমার টাইপ ';
$lang['Customer_Id']='কাস্টমার আইডি';
$lang['Status']='স্ট্যাটাস ';
$lang['Showing']='স্ট্যাটাস ';
$lang['Entries']='প্রবেশ';
/*customerList*/

/*reference*/
$lang['Reference_List']='রেফারেন্স তালিকা';
/*reference*/

/*editReference*/
$lang['Reference_Edit']='রেফারেন্স এডিট';
$lang['Referencen_Name']='রেফারেন্স নাম ';
$lang['Update']='হালনাগাদ';
$lang['Reset']='রিসেট';
/*editReference*/

/*date_wise_product_sales*/
$lang['Date_Wise_Product_Sales_Statement']='তারিখ অনুসারে পণ্য বিক্রয় বিবৃতি';

$lang['Product_Name']='পণ্যের নাম  ';
$lang['Sales_Qty']='বিক্রয় পরিমাণ ';
$lang['Sales_Price']='বিক্রয় মূল্য';
$lang['Total_Sales']='মোট বিক্রয়';
/*date_wise_product_sales*/


/*date_wise_product_sales_by_date*/
$lang['Search']='অনুসন্ধান ';
$lang['Print']='প্রিন্ট';
/*date_wise_product_sales_by_date*/

/*customer_due*/
$lang['From']='থেকে';
$lang['To']='পর্যন্ত';
$lang['Customer_Due_Rec']='গ্রাহকের বাকী রেফা. ';
$lang['Net_Amount']='নেট পরিমাণ';
/*customer_due*/

/*salesReport*/
$lang['From_Date']='তারিখ হইতে';
$lang['To_Date']='এখন পর্যন্ত';
$lang['Memo']='মেমো';
$lang['Total_Sales_Amount']='মোট বিক্রয় পরিমাণ';
/*salesReport*/


/*customerSalesReport*/
$lang['First_Name']='নামের প্রথম অংশ';
$lang['Last_Name']='নামের শেষাংশ';
$lang['Position']='পদমর্যাদা';
$lang['Salary']='বেতন';
/*customerSalesReport*/

/*productWiseSalesReport*/
$lang['Website']='ওয়েবসাইট';
$lang['Stock_Report']='স্টক রিপোর্ট';
$lang['Total_Sales_Price_(Bdt)']='মোট বিক্রয়মূল্য (বিডিটি)';
$lang['Gp_Profit']='Gp_Profit';
/*productWiseSalesReport*/

/*brandWiseProfit*/
$lang['Product_Ledger']='প্রোডাক্ট লেজার ';
$lang['Product_Ledger_Report']='প্রোডাক্ট লেজার রিপোর্ট';
$lang['Voucher']='ভাউচার';
$lang['Stock_In']='স্টক ইন';
$lang['Stock_Out']='স্টক আউট';
$lang['Balance']='ব্যালেন্স';
/*brandWiseProfit*/


/*cylinder_sales_report*/
$lang['Cylinder_Sales_Report']='';
$lang['Customer_Wise_Sales_Report']='';
$lang['Sold_Product']='';
$lang['Recive_Product']='';
$lang['Quantity_Received']='';
$lang['Quantity_Sold']='';
$lang['Rate']='';
/*cylinder_sales_report*/


/*cylinder_sales_report*/
$lang['Customer_Wise_Sales_Report']='গ্রাহক অনুযায়ী বিক্রয় রিপোর্ট';
$lang['Sold_Product']='বিক্রয় পণ্য';
$lang['Quantity_Received']='পণ্য গ্রহণ';
$lang['Quantity_Sold']='বিক্রীত পরিমাণ ';
$lang['Rate']='দাম';
/*cylinder_sales_report*/


/*Cylinder_Sales_Report*/
$lang['Cylinder_Sales_Report']='সিলিন্ডার বিক্রয় রিপোর্ট';
/*Cylinder_Sales_Report*/


/*sales_report_brand_wise*/
/*sales_report_brand_wise*/
/*daily_sales_statement*/
/*daily_sales_statement*/


/*purchases_add*/
$lang['Purchases_Date']='ক্রয় তারিখ ';
$lang['Supplier_Id']='সরবরাহকারীর আইডি';
$lang['Due_Date']='বাকির তারিখ';
$lang['Payment_Type']='পেমেন্ট টাইপ';
$lang['Voucher_Id']='ভাউচার আইডি';
$lang['Purchases_Item']='ক্রয় পণ্য';
$lang['Returnable_Qty']='ফেরতযোগ্য(পরিমাণ)';
$lang['Unit_Price_Bdt']='ইউনিটের দাম (বিডিটি)';
$lang['Total_Price_Bdt']='মোট মূল্য (বিডিটি)';
$lang['Returned_Cylinder']='মোট মূল্য (বিডিটি)';
$lang['Previous_Due']='পূর্বের বাকী ';
$lang['Total_Due']='মোট বাকী';
/*purchases_add*/

/*purchases_list*/
$lang['Purchases_List']='ক্রয়ের তালিকা';
$lang['Pv_No']='পিভি নং ';
$lang['Supplier']='সরবরাহকারী';
$lang['Records']='রেকর্ড';
/*purchases_list*/


/*viewPurchases*/
$lang['Purchases_View']='ক্রয় দেখুন';
$lang['Return_Product']='ফেরত পণ্য ';
$lang['Quantity_Return']=' পণ্য ফেরত';
$lang['Quantity']='পরিমাণ';
$lang['Unit_Price']='একক দাম';
$lang['Total_Price']='মোট দাম';
/*viewPurchases*/


/*supplierPayment*/
$lang['Supplier_Payment_Add']='সরবরাহকারী পেমেন্ট যোগ করা';
$lang['Supplier_Payment']='সরবরাহকারীর টাকা প্রদান';
$lang['Payment_Date']='টাকা প্রদানের তারিখ';
$lang['Supplier_Payment_List']='সরবরাহকারী পারিশ্রমিকেরতালিকা';
$lang['Search_By_Account_Head']='Search_By_Account_Head';
/*supplierPayment*/

/*supPendingCheque*/
$lang['Supplier_Pending_Cheque']='সরবরাহকারীর প্রেন্ডিং চেক';
$lang['Supplier_Name']='সরবরাহকারী নাম';
$lang['Bank_Branch']='ব্যাংকের শাখা';
$lang['Cheque_No']='চেক নং';
$lang['Cheque_Date']='চেকের তারিখ ';
$lang['Amount_In_Bdt']='পরিমাণ (বিডিটিতে)';
/*supPendingCheque*/

/*Supplier_List*/
$lang['Supplier_Add']='সরবরাহকারী যুক্ত করা';
/*Supplier_List*/

/*productCatList*/
$lang['Product_Category']='পন্যের  বিভাগ';
$lang['Product_Cat_Name']='পণ্য বিভাগের নাম  ';
$lang['Product_Category_Add']='পণ্যের বিভাগ যুক্ত করা';
/*productCatList*/


/*addProduct*/
$lang['Add_Product']='পণ্যের যুক্ত করা ';
$lang['Product_Code']='পণ্যের কোড  ';
$lang['Model_Name']='মডেলের নাম ';
$lang['Purchases_Price']='ক্রয় মূল্য';
$lang['Retail_Price_Mrp']='খুচরা মূল্য (এমআরপি)';
$lang['Wholesale_Price']='পাইকারি দাম';
$lang['Alarm_Quantity']='পরিমাণের সতর্ক সংকেত ';
/*addProduct*/

/*brand*/
$lang['Brand_List']='ব্র্যান্ড তালিকা';
$lang['Brand_Add']='ব্র্যান্ড যোগ করা';
$lang['Brand_Title']='ব্র্যান্ড শিরোনাম';
/*brand*/

/*band_add */
$lang['Band_Name']='ব্র্যান্ড নাম';
/*band_add */


/*unit */
$lang['Unit_List']='একক তালিকা ';
$lang['Unit_Name']='একক নাম ';
$lang['Unit_Code']='একক কোড';
/*unit */

/*unitAdd */
$lang['Unit_Add']='ইউনিট অ্যাড';
/*unitAdd */

/*productBarcode */
$lang['Product_Barcode']='পণ্যের বারকোড';
$lang['Product_Barcode_List']='পণ্যের বারকোড তালিকা';
$lang['All_Check']='সমস্ত চেক';
$lang['All_Product']='সমস্ত চেক';
$lang['Generate_Barcode']='বারকোড জেনারেট করুন';
/*productBarcode */


/*addproductTyp */
$lang['Product_Type_Name']='পণ্যের ধরণের নাম';
$lang['Description']='বর্ণনা';
/*addproductTyp */

